## Tools for Statistics Instruction using R and Shiny
========================================================

Author:  This app was originally built by  <a href="http://kylehardman.com/" target="_blank">Kyle Hardman</a> at the University of Missouri.  Hardman made the code available on his blog.

Modifications and extensions of its capabilities were produced by Bruce Dudek at the University at Albany and Jason Bryer at Excelsior College.

Built using <a href="http://www.rstudio.com/shiny" target="_blank"> Shiny </a> by <a href="http://www.rstudio.com/" target="_blank">Rstudio </a> and <a href="http://www.r-project.org/" target="_blank">R</a>, the Statistical Programming Language.

Ver 1.2, Jan. 29, 2018

