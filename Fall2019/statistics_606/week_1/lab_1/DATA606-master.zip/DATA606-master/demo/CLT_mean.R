cat('This Shiny app was developed by ShinyEd: https://github.com/ShinyEd/ShinyEd')

shiny::runApp(paste0(find.package('DATA606'), '/shiny/CLT_mean'))
